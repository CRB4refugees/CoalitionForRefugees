# CoalitionForRefugees
A website for the Coalition for Refugees from Burma.

##List of Includes:

1. {% include head.html %}

2. {% include mobile_nav.html %}

3. (optional) {% include social-media.html %}

4.  {% include header.html%}

5. (optional) {% for post in site.posts limit:3 %}

6. (optional) {% include fourWideCircleImages.html%}

7. {% include footer.html%}

8. Image: consider in tandem with front matter:

---
image: path/to/post/image.jpg
---

{% if page.image %}
<meta property="og:image" content="path/to/post/image.jpg">
{% else %}
<meta property="og:image" content="path/to/page/image.jpg">
{% endif %}
